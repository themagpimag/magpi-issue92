var config = {

	...

	modules: [
		{
			module: "clock",
			position: "top_left",
			classes: 'default'
		},
		{
			module: "compliments",
			position: "lower_third",
			config: {
				compliments: {
					anytime: [
						"Hey, PJ!"
					]
				}
			},
			classes: 'pj'

		},
		{
			module: 'MMM-Facial-Recognition',
			config: {
				// Array with usernames (copy and paste from training script)
				users: ['pj']
			}
		}
	]

};
