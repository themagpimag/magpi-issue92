
{
	module: 'MMM-Facial-Recognition',
	config: {
		// Array with usernames (copy and paste from training script)
		users: ['pj']
	}
}
